import { useState, useEffect } from "react";
import SplashScreen from "./components/SplashScreen";
import WelcomeScreen from "./components/WelcomeScreen";
import SignInScreen from "./components/SignInScreen";
import RegisterScreen from "./components/RegisterScreen";
import MainHomeScreen from "./components/MainHomeScreen";
import MinigamesScreen from "./components/MinigamesScreen";
import ResultsScreen from "./components/ResultsScreen";
import NewsScreen from "./components/NewsScreen";
import CreditsScreen from "./components/CreditsScreen";
import ProfileScreen from "./components/ProfileScreen";
import AdminDashboardScreen from "./components/AdminDashboardScreen";
import AdminUsersScreen from "./components/AdminUsersScreen";
import AdminAnalyticsScreen from "./components/AdminAnalyticsScreen";
import AdminReportsScreen from "./components/AdminReportsScreen";

type Role = "user" | "admin";

type Screen =
  | "splash"
  | "welcome"
  | "signin"
  | "register"
  // usuario
  | "home"
  | "minigames"
  | "results"
  | "news"
  | "credits"
  | "profile"
  // admin
  | "admin-dashboard"
  | "admin-users"
  | "admin-analytics"
  | "admin-reports";

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<Screen>("splash");
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [role, setRole] = useState<Role>("user");

  useEffect(() => {
    if (currentScreen === "splash") {
      const timer = setTimeout(() => setCurrentScreen("welcome"), 2500);
      return () => clearTimeout(timer);
    }
  }, [currentScreen]);

  const handleSignIn = (incomingRole: Role) => {
    setIsAuthenticated(true);
    setRole(incomingRole);
    setCurrentScreen(incomingRole === "admin" ? "admin-dashboard" : "home");
  };

  const handleRegister = () => {
    setIsAuthenticated(true);
    setRole("user");
    setCurrentScreen("home");
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    setRole("user");
    setCurrentScreen("welcome");
  };

  const handleNavigate = (screen: string) => {
    setCurrentScreen(screen as Screen);
  };

  const adminProps = { onNavigate: handleNavigate, onLogout: handleLogout };
  const isAdmin = isAuthenticated && role === "admin";
  const isUser = isAuthenticated && role === "user";

  return (
    <div className="size-full flex items-center justify-center bg-muted">

      {/* ── Auth ── */}
      {currentScreen === "splash" && <SplashScreen />}

      {currentScreen === "welcome" && (
        <WelcomeScreen
          onSignIn={() => setCurrentScreen("signin")}
          onCreateAccount={() => setCurrentScreen("register")}
        />
      )}

      {currentScreen === "signin" && (
        <SignInScreen
          onBack={() => setCurrentScreen("welcome")}
          onSignIn={handleSignIn}
          onGoToRegister={() => setCurrentScreen("register")}
        />
      )}

      {currentScreen === "register" && (
        <RegisterScreen
          onBack={() => setCurrentScreen("welcome")}
          onRegister={handleRegister}
          onGoToSignIn={() => setCurrentScreen("signin")}
        />
      )}

      {/* ── Admin portal ── */}
      {currentScreen === "admin-dashboard" && isAdmin && (
        <AdminDashboardScreen {...adminProps} />
      )}
      {currentScreen === "admin-users" && isAdmin && (
        <AdminUsersScreen {...adminProps} />
      )}
      {currentScreen === "admin-analytics" && isAdmin && (
        <AdminAnalyticsScreen {...adminProps} />
      )}
      {currentScreen === "admin-reports" && isAdmin && (
        <AdminReportsScreen {...adminProps} />
      )}

      {/* ── User app ── */}
      {currentScreen === "home" && isUser && (
        <MainHomeScreen onNavigate={handleNavigate} />
      )}
      {currentScreen === "minigames" && isUser && (
        <MinigamesScreen
          onNavigate={handleNavigate}
          onPlayGame={() => setCurrentScreen("results")}
        />
      )}
      {currentScreen === "results" && isUser && (
        <ResultsScreen
          onBack={() => setCurrentScreen("minigames")}
          onPlayAgain={() => setCurrentScreen("results")}
          onShare={() => alert("Share functionality would open native share sheet")}
        />
      )}
      {currentScreen === "news" && isUser && (
        <NewsScreen onNavigate={handleNavigate} />
      )}
      {currentScreen === "credits" && isUser && (
        <CreditsScreen onNavigate={handleNavigate} />
      )}
      {currentScreen === "profile" && isUser && (
        <ProfileScreen onNavigate={handleNavigate} onLogout={handleLogout} />
      )}
    </div>
  );
}
