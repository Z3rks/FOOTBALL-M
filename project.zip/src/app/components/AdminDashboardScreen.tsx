import {
  AreaChart,
  Area,
  ResponsiveContainer,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
} from "recharts";
import {
  Users,
  Flame,
  Gamepad2,
  Target,
  TrendingUp,
  TrendingDown,
  RefreshCw,
  LogOut,
  ShieldCheck,
  AlertCircle,
  LayoutDashboard,
  BarChart2,
  FileText,
} from "lucide-react";
import AdminBottomNav from "./AdminBottomNav";

interface AdminDashboardScreenProps {
  onNavigate: (screen: string) => void;
  onLogout: () => void;
}

const dauData = [
  { day: "Lun", users: 980 },
  { day: "Mar", users: 1120 },
  { day: "Mié", users: 1340 },
  { day: "Jue", users: 1190 },
  { day: "Vie", users: 1480 },
  { day: "Sáb", users: 1820 },
  { day: "Dom", users: 1203 },
];

const miniGameStats = [
  { name: "Who is it?", plays: 18420, avgScore: 7.4, trend: "up" },
  { name: "Silhouette", plays: 14210, avgScore: 6.1, trend: "down" },
  { name: "Guess Badge", plays: 9870, avgScore: 5.8, trend: "up" },
  { name: "Guess Stadium", plays: 7540, avgScore: 6.9, trend: "up" },
];

const ChartTooltip = ({
  active,
  payload,
  label,
}: {
  active?: boolean;
  payload?: { value: number; color?: string }[];
  label?: string;
}) => {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-white border border-border rounded-lg px-3 py-2 shadow-lg text-xs">
      {label && <p className="font-semibold text-foreground mb-1">{label}</p>}
      {payload.map((p, i) => (
        <p key={i} style={{ color: p.color ?? "#1A5276" }} className="font-medium">
          {p.value.toLocaleString()}
        </p>
      ))}
    </div>
  );
};

function KpiTile({
  label, value, delta, positive, icon: Icon, color, bg,
}: {
  label: string; value: string; delta: string; positive: boolean;
  icon: React.ElementType; color: string; bg: string;
}) {
  return (
    <div className={`${bg} rounded-2xl p-4`}>
      <div className="flex items-start justify-between mb-3">
        <div className="w-9 h-9 rounded-xl flex items-center justify-center bg-white shadow-sm">
          <Icon className="w-5 h-5" style={{ color }} />
        </div>
        <div className={`flex items-center gap-1 text-xs font-semibold ${positive ? "text-emerald-600" : "text-red-500"}`}>
          {positive ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
          {delta}
        </div>
      </div>
      <p className="text-2xl font-bold text-foreground leading-none">{value}</p>
      <p className="text-xs text-muted-foreground mt-1">{label}</p>
    </div>
  );
}

export default function AdminDashboardScreen({ onNavigate, onLogout }: AdminDashboardScreenProps) {
  return (
    <div className="h-screen w-full max-w-[375px] mx-auto bg-background flex flex-col">
      {/* Header */}
      <div className="bg-secondary px-4 pt-4 pb-3 shadow-lg">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-accent/20 flex items-center justify-center">
              <ShieldCheck className="w-5 h-5 text-accent" />
            </div>
            <div>
              <p className="text-white/50 text-[10px] font-bold uppercase tracking-widest leading-none">Admin Portal</p>
              <p className="text-white font-bold text-sm leading-tight">Football Maestro</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button className="w-8 h-8 bg-white/10 rounded-full flex items-center justify-center hover:bg-white/20 transition-colors">
              <RefreshCw className="w-3.5 h-3.5 text-white/70" />
            </button>
            <button
              onClick={onLogout}
              className="flex items-center gap-1.5 bg-white/10 px-3 py-1.5 rounded-full text-white/80 text-xs font-semibold hover:bg-white/20 transition-colors"
            >
              <LogOut className="w-3.5 h-3.5" />
              Salir
            </button>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto pb-20">
        <div className="p-4 space-y-4">
          {/* Encabezado */}
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-base font-bold text-foreground">Vista General</h2>
              <p className="text-xs text-muted-foreground">Hoy, 16 sep 2026 · 14:32</p>
            </div>
            <div className="bg-emerald-50 border border-emerald-200 px-2.5 py-1 rounded-full flex items-center gap-1.5">
              <div className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
              <span className="text-xs font-semibold text-emerald-600">En línea</span>
            </div>
          </div>

          {/* Alertas del sistema */}
          <div className="space-y-2">
            {[
              { type: "warn" as const, msg: "Retención día 7 bajó 3% vs semana pasada" },
              { type: "info" as const, msg: "384k partidas completadas — nuevo récord" },
            ].map(({ type, msg }, i) => (
              <div
                key={i}
                className={`flex items-start gap-2 px-3 py-2.5 rounded-xl text-xs font-medium ${
                  type === "warn"
                    ? "bg-amber-50 border border-amber-200 text-amber-700"
                    : "bg-blue-50 border border-blue-200 text-blue-700"
                }`}
              >
                <AlertCircle className="w-4 h-4 flex-shrink-0 mt-0.5" />
                <span>{msg}</span>
              </div>
            ))}
          </div>

          {/* KPIs 2×2 */}
          <div className="grid grid-cols-2 gap-3">
            <KpiTile label="Usuarios totales" value="12,847" delta="+8%" positive icon={Users} color="#1A5276" bg="bg-blue-50" />
            <KpiTile label="Activos hoy" value="1,203" delta="+12%" positive icon={Flame} color="#F0B429" bg="bg-amber-50" />
            <KpiTile label="Partidas hoy" value="4,821" delta="+5%" positive icon={Gamepad2} color="#34d399" bg="bg-emerald-50" />
            <KpiTile label="Precisión media" value="73%" delta="-2%" positive={false} icon={Target} color="#fb7185" bg="bg-red-50" />
          </div>

          {/* DAU área */}
          <div className="bg-card border border-border rounded-2xl p-4 shadow-sm">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-bold text-foreground">Usuarios Activos / Día</h3>
              <span className="text-xs text-emerald-500 font-semibold flex items-center gap-1">
                <TrendingUp className="w-3 h-3" /> +18% esta semana
              </span>
            </div>
            <ResponsiveContainer width="100%" height={130}>
              <AreaChart data={dauData} margin={{ top: 4, right: 4, left: -24, bottom: 0 }}>
                <defs>
                  <linearGradient id="dauGradDb" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#1A5276" stopOpacity={0.25} />
                    <stop offset="95%" stopColor="#1A5276" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(26,82,118,0.08)" vertical={false} />
                <XAxis dataKey="day" tick={{ fontSize: 10, fill: "#9ca3af" }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 10, fill: "#9ca3af" }} axisLine={false} tickLine={false} />
                <Tooltip content={<ChartTooltip />} />
                <Area
                  type="monotone"
                  dataKey="users"
                  stroke="#1A5276"
                  strokeWidth={2}
                  fill="url(#dauGradDb)"
                  dot={{ r: 3.5, fill: "#1A5276", stroke: "#fff", strokeWidth: 2 }}
                  activeDot={{ r: 5.5, fill: "#F0B429", stroke: "#fff", strokeWidth: 2 }}
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>

          {/* Ranking mini-juegos */}
          <div className="bg-card border border-border rounded-2xl p-4 shadow-sm">
            <h3 className="text-sm font-bold text-foreground mb-3">Ranking de Mini-juegos</h3>
            <div className="space-y-3">
              {miniGameStats.map(({ name, plays, avgScore, trend }, i) => (
                <div key={`mg-${i}`} className="flex items-center gap-3">
                  <span className="w-5 text-xs font-bold text-muted-foreground text-right flex-shrink-0">{i + 1}</span>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between mb-1">
                      <p className="text-xs font-semibold text-foreground truncate">{name}</p>
                      <div className="flex items-center gap-2 flex-shrink-0">
                        <span className={`text-xs font-bold ${trend === "up" ? "text-emerald-500" : "text-red-400"}`}>
                          {trend === "up" ? "▲" : "▼"} {avgScore}
                        </span>
                        <span className="text-xs text-muted-foreground">{(plays / 1000).toFixed(1)}k</span>
                      </div>
                    </div>
                    <div className="w-full h-1.5 bg-muted rounded-full overflow-hidden">
                      <div className="h-full rounded-full bg-primary" style={{ width: `${(plays / 18420) * 100}%` }} />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Accesos rápidos */}
          <div className="grid grid-cols-3 gap-2">
            {[
              { label: "Usuarios", icon: Users, screen: "admin-users" },
              { label: "Analytics", icon: BarChart2, screen: "admin-analytics" },
              { label: "Reportes", icon: FileText, screen: "admin-reports" },
            ].map(({ label, icon: Icon, screen }) => (
              <button
                key={screen}
                onClick={() => onNavigate(screen)}
                className="bg-card border border-border rounded-xl p-3 flex flex-col items-center gap-2 shadow-sm hover:shadow-md hover:border-primary/30 transition-all"
              >
                <Icon className="w-5 h-5 text-primary" />
                <span className="text-xs font-semibold text-foreground">{label}</span>
              </button>
            ))}
          </div>
        </div>
      </div>

      <AdminBottomNav active="admin-dashboard" onNavigate={onNavigate} />
    </div>
  );
}
