import { useState } from "react";
import { Search, MoreVertical, Circle, ShieldCheck, LogOut, RefreshCw, UserPlus, Download } from "lucide-react";
import AdminBottomNav from "./AdminBottomNav";

interface AdminUsersScreenProps {
  onNavigate: (screen: string) => void;
  onLogout: () => void;
}

const allUsers = [
  { id: 1, name: "CarlosR99", email: "carlos@mail.com", level: 15, streak: 12, xp: 21340, status: "active", joined: "Hace 2 días", country: "🇪🇸" },
  { id: 2, name: "LauraFM", email: "laura@mail.com", level: 8, streak: 4, xp: 16750, status: "active", joined: "Hace 5 días", country: "🇲🇽" },
  { id: 3, name: "MarcoBR", email: "marco@mail.com", level: 22, streak: 31, xp: 24810, status: "active", joined: "Hace 3 sem", country: "🇧🇷" },
  { id: 4, name: "SofíaG", email: "sofia@mail.com", level: 3, streak: 0, xp: 4210, status: "inactive", joined: "Hace 1 día", country: "🇦🇷" },
  { id: 5, name: "IvanKP", email: "ivan@mail.com", level: 11, streak: 7, xp: 18920, status: "active", joined: "Hace 2 sem", country: "🇩🇪" },
  { id: 6, name: "AnaML", email: "ana@mail.com", level: 6, streak: 0, xp: 8340, status: "inactive", joined: "Hace 4 días", country: "🇫🇷" },
  { id: 7, name: "Pedro_V", email: "pedro@mail.com", level: 19, streak: 22, xp: 15210, status: "active", joined: "Hace 1 mes", country: "🇵🇹" },
  { id: 8, name: "JuanDB", email: "juan@mail.com", level: 5, streak: 1, xp: 6820, status: "active", joined: "Hace 3 días", country: "🇨🇴" },
  { id: 9, name: "ElenaVP", email: "elena@mail.com", level: 13, streak: 9, xp: 19540, status: "active", joined: "Hace 1 sem", country: "🇮🇹" },
  { id: 10, name: "OmarKH", email: "omar@mail.com", level: 7, streak: 0, xp: 9120, status: "inactive", joined: "Hace 6 días", country: "🇲🇦" },
];

type FilterType = "all" | "active" | "inactive" | "new";

const filterCounts = { all: 12847, active: 9210, inactive: 3637, new: 432 };

export default function AdminUsersScreen({ onNavigate, onLogout }: AdminUsersScreenProps) {
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState<FilterType>("all");
  const [selectedUser, setSelectedUser] = useState<number | null>(null);

  const filtered = allUsers.filter((u) => {
    const matchSearch =
      u.name.toLowerCase().includes(search.toLowerCase()) ||
      u.email.toLowerCase().includes(search.toLowerCase());
    const matchFilter =
      filter === "all" ||
      (filter === "active" && u.status === "active") ||
      (filter === "inactive" && u.status === "inactive") ||
      (filter === "new" && u.streak <= 1);
    return matchSearch && matchFilter;
  });

  return (
    <div className="h-screen w-full max-w-[375px] mx-auto bg-background flex flex-col">
      {/* Header */}
      <div className="bg-secondary px-4 pt-4 pb-3 shadow-lg">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-accent/20 flex items-center justify-center">
              <ShieldCheck className="w-5 h-5 text-accent" />
            </div>
            <div>
              <p className="text-white/50 text-[10px] font-bold uppercase tracking-widest leading-none">Admin Portal</p>
              <p className="text-white font-bold text-sm leading-tight">Gestión de Usuarios</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button className="w-8 h-8 bg-white/10 rounded-full flex items-center justify-center hover:bg-white/20 transition-colors">
              <UserPlus className="w-3.5 h-3.5 text-white/70" />
            </button>
            <button
              onClick={onLogout}
              className="flex items-center gap-1.5 bg-white/10 px-3 py-1.5 rounded-full text-white/80 text-xs font-semibold hover:bg-white/20 transition-colors"
            >
              <LogOut className="w-3.5 h-3.5" />
              Salir
            </button>
          </div>
        </div>

        {/* Buscador integrado en header */}
        <div className="flex items-center gap-2 bg-white/10 rounded-xl px-3 py-2">
          <Search className="w-4 h-4 text-white/50 flex-shrink-0" />
          <input
            type="text"
            placeholder="Buscar usuario o email…"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="flex-1 bg-transparent text-sm text-white placeholder:text-white/40 focus:outline-none"
          />
          {search && (
            <button onClick={() => setSearch("")} className="text-white/50 hover:text-white text-xs">✕</button>
          )}
        </div>
      </div>

      <div className="flex-1 overflow-y-auto pb-20">
        <div className="p-4 space-y-3">
          {/* Filtros */}
          <div className="flex gap-2 overflow-x-auto scrollbar-hide pb-1">
            {(Object.entries({ all: "Todos", active: "Activos", inactive: "Inactivos", new: "Nuevos (7d)" }) as [FilterType, string][]).map(
              ([key, label]) => (
                <button
                  key={key}
                  onClick={() => setFilter(key)}
                  className={`flex-shrink-0 px-3 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition-all ${
                    filter === key
                      ? "bg-primary text-white shadow-sm"
                      : "bg-muted text-muted-foreground hover:bg-primary/10"
                  }`}
                >
                  {label} · {filterCounts[key].toLocaleString()}
                </button>
              )
            )}
          </div>

          {/* Conteo y exportar */}
          <div className="flex items-center justify-between">
            <p className="text-xs text-muted-foreground">
              <span className="font-bold text-foreground">{filtered.length}</span> usuarios mostrados
            </p>
            <button className="flex items-center gap-1 text-xs font-semibold text-primary hover:text-secondary transition-colors">
              <Download className="w-3.5 h-3.5" />
              Exportar
            </button>
          </div>

          {/* Lista de usuarios */}
          <div className="space-y-2">
            {filtered.map((user) => (
              <div key={user.id}>
                <div
                  onClick={() => setSelectedUser(selectedUser === user.id ? null : user.id)}
                  className="bg-card border border-border rounded-xl p-3.5 flex items-center gap-3 shadow-sm cursor-pointer hover:border-primary/30 transition-all"
                >
                  {/* Avatar */}
                  <div className="w-11 h-11 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0 relative">
                    <span className="text-sm font-bold text-primary">
                      {user.name.slice(0, 2).toUpperCase()}
                    </span>
                    <span className="absolute -bottom-0.5 -right-0.5 text-sm">{user.country}</span>
                  </div>

                  {/* Info */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-0.5">
                      <p className="text-sm font-bold text-foreground truncate">{user.name}</p>
                      <Circle
                        className={`w-2 h-2 flex-shrink-0 ${
                          user.status === "active" ? "fill-emerald-400 text-emerald-400" : "fill-gray-300 text-gray-300"
                        }`}
                      />
                    </div>
                    <p className="text-xs text-muted-foreground truncate">{user.email}</p>
                    <div className="flex items-center gap-3 mt-1">
                      <span className="text-xs text-muted-foreground">Nv <span className="font-bold text-foreground">{user.level}</span></span>
                      <span className="text-xs text-muted-foreground">🔥 <span className="font-bold text-foreground">{user.streak}d</span></span>
                      <span className="text-xs text-muted-foreground">{user.xp.toLocaleString()} XP</span>
                    </div>
                  </div>

                  <button
                    onClick={(e) => { e.stopPropagation(); setSelectedUser(selectedUser === user.id ? null : user.id); }}
                    className="p-1.5 hover:bg-muted rounded-lg transition-colors flex-shrink-0"
                  >
                    <MoreVertical className="w-4 h-4 text-muted-foreground" />
                  </button>
                </div>

                {/* Panel de acciones expandible */}
                {selectedUser === user.id && (
                  <div className="bg-muted/60 border border-border border-t-0 rounded-b-xl px-4 py-3 -mt-1">
                    <p className="text-xs font-bold text-muted-foreground uppercase tracking-wider mb-2">Acciones</p>
                    <div className="grid grid-cols-3 gap-2">
                      {[
                        { label: "Ver perfil", color: "text-primary" },
                        { label: user.status === "active" ? "Suspender" : "Activar", color: user.status === "active" ? "text-amber-600" : "text-emerald-600" },
                        { label: "Eliminar", color: "text-red-500" },
                      ].map(({ label, color }) => (
                        <button
                          key={label}
                          className={`text-xs font-semibold py-2 px-1 rounded-lg bg-white border border-border hover:shadow-sm transition-all ${color}`}
                        >
                          {label}
                        </button>
                      ))}
                    </div>
                    <div className="mt-2 pt-2 border-t border-border/50 grid grid-cols-2 gap-2 text-xs text-muted-foreground">
                      <span>Registrado: {user.joined}</span>
                      <span className="text-right">Estado: <span className={`font-semibold ${user.status === "active" ? "text-emerald-600" : "text-gray-500"}`}>{user.status === "active" ? "Activo" : "Inactivo"}</span></span>
                    </div>
                  </div>
                )}
              </div>
            ))}

            {filtered.length === 0 && (
              <div className="text-center py-16 text-muted-foreground">
                <Search className="w-10 h-10 mx-auto mb-3 opacity-30" />
                <p className="text-sm font-medium">Sin resultados</p>
                <p className="text-xs mt-1">Intenta con otro término o filtro</p>
              </div>
            )}
          </div>
        </div>
      </div>

      <AdminBottomNav active="admin-users" onNavigate={onNavigate} />
    </div>
  );
}
