import { Trophy, Flame, Brain, User, Newspaper, Coins, Target, Award, TrendingUp } from "lucide-react";
import BottomNav from "./BottomNav";

interface MainHomeScreenProps {
  onNavigate: (screen: string) => void;
}

const miniGamesPreview = [
  { id: 1, name: "Who is it?", icon: "🤔", difficulty: "Easy" },
  { id: 2, name: "Silhouette", icon: "👤", difficulty: "Medium" },
  { id: 3, name: "Guess the Badge", icon: "🛡️", difficulty: "Hard" },
  { id: 4, name: "Guess the Stadium", icon: "🏟️", difficulty: "Medium" },
];

const newsPreview = [
  {
    id: 1,
    title: "Real Madrid wins Champions League final",
    source: "ESPN",
    timeAgo: "2h ago",
    image: "https://images.unsplash.com/photo-1579952363873-27f3bade9f55?w=400&h=200&fit=crop",
  },
  {
    id: 2,
    title: "Record transfer: Mbappé moves to new club",
    source: "Sky Sports",
    timeAgo: "5h ago",
    image: "https://images.unsplash.com/photo-1522778119026-d647f0596c20?w=400&h=200&fit=crop",
  },
];

export default function MainHomeScreen({ onNavigate }: MainHomeScreenProps) {
  return (
    <div className="h-screen w-full max-w-[375px] mx-auto bg-background flex flex-col">
      {/* Header */}
      <div className="bg-primary px-4 py-4 shadow-md">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-full bg-accent flex items-center justify-center font-bold text-primary">
              FM
            </div>
            <div>
              <p className="text-white/80 text-xs">Welcome back!</p>
              <p className="text-white font-semibold text-base">FootballFan123</p>
            </div>
          </div>
          <div className="flex gap-3">
            <div className="flex items-center gap-1.5 bg-white/10 px-3 py-1.5 rounded-full">
              <Trophy className="w-4 h-4 text-accent" />
              <span className="text-white text-sm font-semibold">Lvl 12</span>
            </div>
            <div className="flex items-center gap-1.5 bg-white/10 px-3 py-1.5 rounded-full">
              <Flame className="w-4 h-4 text-accent" />
              <span className="text-white text-sm font-semibold">7</span>
            </div>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto pb-20">
        {/* Daily Challenge Hero Card */}
        <div className="p-4">
          <div className="bg-gradient-to-br from-primary to-secondary rounded-2xl p-6 shadow-lg">
            <div className="flex items-start justify-between mb-4">
              <div>
                <p className="text-accent text-sm font-semibold mb-1">DAILY CHALLENGE</p>
                <h3 className="text-white text-xl font-bold">Football Trivia Blitz</h3>
              </div>
              <div className="bg-accent text-primary text-xs font-bold px-3 py-1.5 rounded-full">
                +50 XP
              </div>
            </div>
            <p className="text-white/90 text-sm mb-5">Answer 10 quick questions about today's matches!</p>
            <button className="w-full bg-accent text-primary py-3 rounded-xl font-bold hover:bg-accent/90 transition-colors shadow-md">
              Play Now
            </button>
          </div>
        </div>

        {/* Mini-games Section */}
        <div className="px-4 pb-4">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-lg font-bold text-foreground">Mini-games</h3>
            <button
              onClick={() => onNavigate("minigames")}
              className="text-sm text-primary hover:text-secondary font-semibold"
            >
              See all
            </button>
          </div>
          <div className="flex gap-3 overflow-x-auto pb-2 scrollbar-hide">
            {miniGamesPreview.map((game) => (
              <div
                key={game.id}
                className="flex-shrink-0 w-32 bg-card border border-border rounded-xl p-4 shadow-sm hover:shadow-md transition-shadow cursor-pointer"
              >
                <div className="text-3xl mb-2">{game.icon}</div>
                <p className="text-sm font-semibold text-foreground mb-1">{game.name}</p>
                <span className="text-xs text-muted-foreground">{game.difficulty}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Latest News Section */}
        <div className="px-4 pb-4">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-lg font-bold text-foreground">Latest Football News</h3>
            <button
              onClick={() => onNavigate("news")}
              className="text-sm text-primary hover:text-secondary font-semibold"
            >
              See all
            </button>
          </div>
          <div className="space-y-3">
            {newsPreview.map((article) => (
              <div key={article.id} className="bg-card border border-border rounded-xl overflow-hidden shadow-sm">
                <img src={article.image} alt={article.title} className="w-full h-32 object-cover" />
                <div className="p-3">
                  <h4 className="font-semibold text-sm text-foreground mb-2 line-clamp-2">{article.title}</h4>
                  <div className="flex items-center gap-2 text-xs text-muted-foreground">
                    <span>{article.source}</span>
                    <span>•</span>
                    <span>{article.timeAgo}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* My Stats Section */}
        <div className="px-4 pb-4">
          <h3 className="text-lg font-bold text-foreground mb-3">My Stats</h3>
          <div className="bg-card border border-border rounded-xl p-4 shadow-sm">
            <div className="grid grid-cols-3 gap-4">
              <div className="text-center">
                <div className="flex justify-center mb-2">
                  <Target className="w-8 h-8 text-primary" />
                </div>
                <p className="text-2xl font-bold text-foreground">87%</p>
                <p className="text-xs text-muted-foreground">Accuracy</p>
              </div>
              <div className="text-center">
                <div className="flex justify-center mb-2">
                  <Award className="w-8 h-8 text-accent" />
                </div>
                <p className="text-2xl font-bold text-foreground">23</p>
                <p className="text-xs text-muted-foreground">Badges</p>
              </div>
              <div className="text-center">
                <div className="flex justify-center mb-2">
                  <TrendingUp className="w-8 h-8 text-chart-4" />
                </div>
                <p className="text-2xl font-bold text-foreground">1,245</p>
                <p className="text-xs text-muted-foreground">Total XP</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Navigation */}
      <BottomNav active="home" onNavigate={onNavigate} />
    </div>
  );
}
