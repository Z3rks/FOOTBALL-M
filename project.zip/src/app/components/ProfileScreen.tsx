import { User, Trophy, Flame, Target, Award, TrendingUp, Settings, LogOut, ChevronRight } from "lucide-react";
import BottomNav from "./BottomNav";

interface ProfileScreenProps {
  onNavigate: (screen: string) => void;
  onLogout: () => void;
}

export default function ProfileScreen({ onNavigate, onLogout }: ProfileScreenProps) {
  return (
    <div className="h-screen w-full max-w-[375px] mx-auto bg-background flex flex-col">
      {/* Header */}
      <div className="bg-primary px-4 py-6 shadow-md">
        <div className="flex flex-col items-center">
          <div className="w-24 h-24 rounded-full bg-accent flex items-center justify-center font-bold text-3xl text-primary mb-3 shadow-lg">
            FM
          </div>
          <h2 className="text-white text-2xl font-bold">FootballFan123</h2>
          <p className="text-white/80 text-sm">footballfan@email.com</p>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto pb-20">
        {/* Stats Grid */}
        <div className="px-4 py-6 grid grid-cols-3 gap-3">
          <div className="bg-card border border-border rounded-xl p-4 text-center shadow-sm">
            <div className="flex justify-center mb-2">
              <Trophy className="w-6 h-6 text-accent" />
            </div>
            <p className="text-2xl font-bold text-foreground">12</p>
            <p className="text-xs text-muted-foreground">Level</p>
          </div>
          <div className="bg-card border border-border rounded-xl p-4 text-center shadow-sm">
            <div className="flex justify-center mb-2">
              <Flame className="w-6 h-6 text-orange-500" />
            </div>
            <p className="text-2xl font-bold text-foreground">7</p>
            <p className="text-xs text-muted-foreground">Day Streak</p>
          </div>
          <div className="bg-card border border-border rounded-xl p-4 text-center shadow-sm">
            <div className="flex justify-center mb-2">
              <Award className="w-6 h-6 text-primary" />
            </div>
            <p className="text-2xl font-bold text-foreground">23</p>
            <p className="text-xs text-muted-foreground">Badges</p>
          </div>
        </div>

        {/* Performance Stats */}
        <div className="px-4 pb-4">
          <h3 className="text-lg font-bold text-foreground mb-3">Performance</h3>
          <div className="bg-card border border-border rounded-xl p-4 shadow-sm space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                  <Target className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <p className="text-sm font-medium text-foreground">Accuracy</p>
                  <p className="text-xs text-muted-foreground">Overall correct answers</p>
                </div>
              </div>
              <p className="text-2xl font-bold text-primary">87%</p>
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-accent/10 rounded-lg flex items-center justify-center">
                  <TrendingUp className="w-5 h-5 text-accent" />
                </div>
                <div>
                  <p className="text-sm font-medium text-foreground">Total XP</p>
                  <p className="text-xs text-muted-foreground">Experience points earned</p>
                </div>
              </div>
              <p className="text-2xl font-bold text-foreground">1,245</p>
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-chart-4/10 rounded-lg flex items-center justify-center">
                  <Trophy className="w-5 h-5 text-chart-4" />
                </div>
                <div>
                  <p className="text-sm font-medium text-foreground">Games Played</p>
                  <p className="text-xs text-muted-foreground">Total mini-games completed</p>
                </div>
              </div>
              <p className="text-2xl font-bold text-foreground">156</p>
            </div>
          </div>
        </div>

        {/* Settings Menu */}
        <div className="px-4 pb-4">
          <h3 className="text-lg font-bold text-foreground mb-3">Settings</h3>
          <div className="bg-card border border-border rounded-xl overflow-hidden shadow-sm divide-y divide-border">
            <button className="w-full flex items-center justify-between p-4 hover:bg-muted transition-colors">
              <div className="flex items-center gap-3">
                <Settings className="w-5 h-5 text-muted-foreground" />
                <span className="font-medium text-foreground">Account Settings</span>
              </div>
              <ChevronRight className="w-5 h-5 text-muted-foreground" />
            </button>

            <button className="w-full flex items-center justify-between p-4 hover:bg-muted transition-colors">
              <div className="flex items-center gap-3">
                <User className="w-5 h-5 text-muted-foreground" />
                <span className="font-medium text-foreground">Edit Profile</span>
              </div>
              <ChevronRight className="w-5 h-5 text-muted-foreground" />
            </button>

            <button
              onClick={onLogout}
              className="w-full flex items-center justify-between p-4 hover:bg-red-50 transition-colors"
            >
              <div className="flex items-center gap-3">
                <LogOut className="w-5 h-5 text-red-600" />
                <span className="font-medium text-red-600">Log Out</span>
              </div>
              <ChevronRight className="w-5 h-5 text-red-600" />
            </button>
          </div>
        </div>
      </div>

      {/* Bottom Navigation */}
      <BottomNav active="profile" onNavigate={onNavigate} />
    </div>
  );
}
