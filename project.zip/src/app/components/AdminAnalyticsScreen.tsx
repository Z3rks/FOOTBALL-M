import {
  AreaChart, Area,
  BarChart, Bar,
  RadarChart, Radar, PolarGrid, PolarAngleAxis,
  LineChart, Line,
  ResponsiveContainer, XAxis, YAxis, Tooltip, CartesianGrid, Cell,
} from "recharts";
import { ShieldCheck, LogOut, TrendingUp } from "lucide-react";
import AdminBottomNav from "./AdminBottomNav";

interface AdminAnalyticsScreenProps {
  onNavigate: (screen: string) => void;
  onLogout: () => void;
}

const monthlyUsers = [
  { month: "Mar", new: 540, active: 2800 },
  { month: "Abr", new: 720, active: 3200 },
  { month: "May", new: 610, active: 3050 },
  { month: "Jun", new: 890, active: 3700 },
  { month: "Jul", new: 1100, active: 4200 },
  { month: "Ago", new: 960, active: 4580 },
];

const retentionData = [
  { day: "Día 1", rate: 100 },
  { day: "Día 3", rate: 74 },
  { day: "Día 7", rate: 52 },
  { day: "Día 14", rate: 38 },
  { day: "Día 30", rate: 24 },
];

const gamesPerCategory = [
  { name: "Players", games: 14820, color: "#1A5276" },
  { name: "Clubs", games: 11340, color: "#F0B429" },
  { name: "History", games: 9870, color: "#34d399" },
  { name: "Rules", games: 8450, color: "#60a5fa" },
  { name: "Stadiums", games: 6210, color: "#a78bfa" },
  { name: "Transfers", games: 4890, color: "#fb7185" },
];

const categoryRadar = [
  { subject: "Players", avg: 76 },
  { subject: "Clubs", avg: 68 },
  { subject: "Stadiums", avg: 61 },
  { subject: "History", avg: 72 },
  { subject: "Transfers", avg: 54 },
  { subject: "Rules", avg: 83 },
];

const sessionDuration = [
  { range: "<2m", pct: 12 },
  { range: "2-5m", pct: 28 },
  { range: "5-10m", pct: 35 },
  { range: "10-20m", pct: 18 },
  { range: ">20m", pct: 7 },
];

const ChartTooltip = ({
  active, payload, label,
}: { active?: boolean; payload?: { value: number; color?: string; name?: string }[]; label?: string }) => {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-white border border-border rounded-lg px-3 py-2 shadow-lg text-xs">
      {label && <p className="font-semibold text-foreground mb-1">{label}</p>}
      {payload.map((p, i) => (
        <p key={i} style={{ color: p.color ?? "#1A5276" }} className="font-medium">
          {p.name && <span className="text-muted-foreground mr-1">{p.name}:</span>}
          {p.value.toLocaleString()}
        </p>
      ))}
    </div>
  );
};

export default function AdminAnalyticsScreen({ onNavigate, onLogout }: AdminAnalyticsScreenProps) {
  return (
    <div className="h-screen w-full max-w-[375px] mx-auto bg-background flex flex-col">
      {/* Header */}
      <div className="bg-secondary px-4 pt-4 pb-3 shadow-lg">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-accent/20 flex items-center justify-center">
              <ShieldCheck className="w-5 h-5 text-accent" />
            </div>
            <div>
              <p className="text-white/50 text-[10px] font-bold uppercase tracking-widest leading-none">Admin Portal</p>
              <p className="text-white font-bold text-sm leading-tight">Analytics</p>
            </div>
          </div>
          <button
            onClick={onLogout}
            className="flex items-center gap-1.5 bg-white/10 px-3 py-1.5 rounded-full text-white/80 text-xs font-semibold hover:bg-white/20 transition-colors"
          >
            <LogOut className="w-3.5 h-3.5" />
            Salir
          </button>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto pb-20">
        <div className="p-4 space-y-4">

          {/* KPIs rápidos de analytics */}
          <div className="grid grid-cols-3 gap-2">
            {[
              { label: "Sesión media", value: "8.4m" },
              { label: "Retención D7", value: "52%" },
              { label: "DAU/MAU", value: "26%" },
            ].map(({ label, value }) => (
              <div key={label} className="bg-card border border-border rounded-xl p-3 text-center shadow-sm">
                <p className="text-lg font-bold text-foreground">{value}</p>
                <p className="text-xs text-muted-foreground mt-0.5 leading-tight">{label}</p>
              </div>
            ))}
          </div>

          {/* Crecimiento de usuarios */}
          <div className="bg-card border border-border rounded-2xl p-4 shadow-sm">
            <h3 className="text-sm font-bold text-foreground mb-0.5">Crecimiento de Usuarios</h3>
            <p className="text-xs text-muted-foreground mb-3">Nuevos registros vs usuarios activos</p>
            <ResponsiveContainer width="100%" height={140}>
              <AreaChart data={monthlyUsers} margin={{ top: 4, right: 4, left: -24, bottom: 0 }}>
                <defs>
                  <linearGradient id="activeGradAn" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#1A5276" stopOpacity={0.2} />
                    <stop offset="95%" stopColor="#1A5276" stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id="newGradAn" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#F0B429" stopOpacity={0.4} />
                    <stop offset="95%" stopColor="#F0B429" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(26,82,118,0.08)" vertical={false} />
                <XAxis dataKey="month" tick={{ fontSize: 10, fill: "#9ca3af" }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 10, fill: "#9ca3af" }} axisLine={false} tickLine={false} />
                <Tooltip content={<ChartTooltip />} />
                <Area type="monotone" dataKey="active" name="Activos" stroke="#1A5276" strokeWidth={2} fill="url(#activeGradAn)" />
                <Area type="monotone" dataKey="new" name="Nuevos" stroke="#F0B429" strokeWidth={2} fill="url(#newGradAn)" />
              </AreaChart>
            </ResponsiveContainer>
            <div className="flex gap-4 mt-2">
              <div className="flex items-center gap-1.5"><div className="w-2.5 h-2.5 rounded-full bg-primary" /><span className="text-xs text-muted-foreground">Activos</span></div>
              <div className="flex items-center gap-1.5"><div className="w-2.5 h-2.5 rounded-full bg-accent" /><span className="text-xs text-muted-foreground">Nuevos</span></div>
            </div>
          </div>

          {/* Curva de retención */}
          <div className="bg-card border border-border rounded-2xl p-4 shadow-sm">
            <h3 className="text-sm font-bold text-foreground mb-0.5">Curva de Retención</h3>
            <p className="text-xs text-muted-foreground mb-3">% de usuarios que siguen activos tras N días</p>
            <ResponsiveContainer width="100%" height={120}>
              <LineChart data={retentionData} margin={{ top: 4, right: 4, left: -24, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(26,82,118,0.08)" vertical={false} />
                <XAxis dataKey="day" tick={{ fontSize: 10, fill: "#9ca3af" }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 10, fill: "#9ca3af" }} axisLine={false} tickLine={false} domain={[0, 100]} />
                <Tooltip
                  formatter={(v: number) => [`${v}%`, "Retención"]}
                  contentStyle={{ background: "#fff", border: "1px solid rgba(26,82,118,0.2)", borderRadius: 8, fontSize: 12 }}
                />
                <Line
                  type="monotone"
                  dataKey="rate"
                  stroke="#F0B429"
                  strokeWidth={2.5}
                  dot={{ r: 4, fill: "#F0B429", stroke: "#fff", strokeWidth: 2 }}
                  activeDot={{ r: 6, fill: "#1A5276", stroke: "#fff", strokeWidth: 2 }}
                />
              </LineChart>
            </ResponsiveContainer>
            <div className="grid grid-cols-3 gap-2 mt-3">
              {[{ label: "Día 1", val: "100%" }, { label: "Día 7", val: "52%" }, { label: "Día 30", val: "24%" }].map(({ label, val }) => (
                <div key={label} className="bg-muted rounded-lg p-2 text-center">
                  <p className="text-sm font-bold text-foreground">{val}</p>
                  <p className="text-xs text-muted-foreground">{label}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Partidas por categoría */}
          <div className="bg-card border border-border rounded-2xl p-4 shadow-sm">
            <h3 className="text-sm font-bold text-foreground mb-3">Partidas por Categoría</h3>
            <ResponsiveContainer width="100%" height={160}>
              <BarChart data={gamesPerCategory} layout="vertical" margin={{ top: 0, right: 32, left: 20, bottom: 0 }} barSize={14}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(26,82,118,0.08)" horizontal={false} />
                <XAxis type="number" tick={{ fontSize: 10, fill: "#9ca3af" }} axisLine={false} tickLine={false}
                  tickFormatter={(v) => `${(v / 1000).toFixed(0)}k`} />
                <YAxis type="category" dataKey="name" tick={{ fontSize: 10, fill: "#6b7280", fontWeight: 600 }}
                  axisLine={false} tickLine={false} width={60} />
                <Tooltip content={<ChartTooltip />} />
                <Bar dataKey="games" radius={[0, 4, 4, 0]}>
                  {gamesPerCategory.map((entry, i) => (
                    <Cell key={`an-cat-${i}`} fill={entry.color} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>

          {/* Duración de sesión */}
          <div className="bg-card border border-border rounded-2xl p-4 shadow-sm">
            <div className="flex items-center justify-between mb-3">
              <div>
                <h3 className="text-sm font-bold text-foreground">Duración de Sesión</h3>
                <p className="text-xs text-muted-foreground">Distribución de tiempo en app</p>
              </div>
              <span className="text-xs text-emerald-500 font-semibold flex items-center gap-1">
                <TrendingUp className="w-3 h-3" /> Media: 8.4m
              </span>
            </div>
            <ResponsiveContainer width="100%" height={100}>
              <BarChart data={sessionDuration} margin={{ top: 4, right: 4, left: -24, bottom: 0 }} barSize={28}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(26,82,118,0.08)" vertical={false} />
                <XAxis dataKey="range" tick={{ fontSize: 10, fill: "#9ca3af" }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 10, fill: "#9ca3af" }} axisLine={false} tickLine={false} />
                <Tooltip
                  formatter={(v: number) => [`${v}%`, "Usuarios"]}
                  contentStyle={{ background: "#fff", border: "1px solid rgba(26,82,118,0.2)", borderRadius: 8, fontSize: 12 }}
                />
                <Bar dataKey="pct" radius={[4, 4, 0, 0]}>
                  {sessionDuration.map((_, i) => (
                    <Cell key={`an-dur-${i}`} fill={i === 2 ? "#F0B429" : "#1A5276"} opacity={i === 2 ? 1 : 0.5} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
            <p className="text-xs text-muted-foreground text-center mt-1">
              El 35% de sesiones duran entre <span className="font-bold text-foreground">5 y 10 minutos</span>
            </p>
          </div>

          {/* Radar precisión */}
          <div className="bg-card border border-border rounded-2xl p-4 shadow-sm">
            <h3 className="text-sm font-bold text-foreground mb-0.5">Precisión por Categoría</h3>
            <p className="text-xs text-muted-foreground mb-2">Promedios de toda la plataforma</p>
            <ResponsiveContainer width="100%" height={200}>
              <RadarChart data={categoryRadar} margin={{ top: 8, right: 24, bottom: 8, left: 24 }}>
                <PolarGrid stroke="rgba(26,82,118,0.15)" />
                <PolarAngleAxis dataKey="subject" tick={{ fontSize: 10, fill: "#6b7280", fontWeight: 600 }} />
                <Radar
                  name="Precisión %"
                  dataKey="avg"
                  stroke="#F0B429"
                  strokeWidth={2}
                  fill="#F0B429"
                  fillOpacity={0.15}
                  dot={{ r: 4, fill: "#1A5276", stroke: "#fff", strokeWidth: 1.5 }}
                />
                <Tooltip
                  formatter={(v: number) => [`${v}%`, "Precisión"]}
                  contentStyle={{ background: "#fff", border: "1px solid rgba(26,82,118,0.2)", borderRadius: 8, fontSize: 12 }}
                />
              </RadarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      <AdminBottomNav active="admin-analytics" onNavigate={onNavigate} />
    </div>
  );
}
