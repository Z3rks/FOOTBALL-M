import { useState } from "react";
import { ArrowLeft, ShieldCheck, User } from "lucide-react";
import { FcGoogle } from "react-icons/fc";

type Role = "user" | "admin";

interface SignInScreenProps {
  onBack: () => void;
  onSignIn: (role: Role) => void;
  onGoToRegister: () => void;
}

export default function SignInScreen({ onBack, onSignIn, onGoToRegister }: SignInScreenProps) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [role, setRole] = useState<Role>("user");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSignIn(role);
  };

  const isAdmin = role === "admin";

  return (
    <div className="h-screen w-full max-w-[375px] mx-auto bg-background flex flex-col">
      {/* Header */}
      <div
        className={`px-4 py-4 flex items-center border-b border-border transition-colors duration-300 ${
          isAdmin ? "bg-secondary" : "bg-background"
        }`}
      >
        <button onClick={onBack} className="p-2 -ml-2 hover:bg-muted/20 rounded-lg transition-colors">
          <ArrowLeft className={`w-5 h-5 ${isAdmin ? "text-white" : "text-foreground"}`} />
        </button>
        <h2 className={`flex-1 text-center text-xl font-semibold -ml-9 ${isAdmin ? "text-white" : "text-foreground"}`}>
          {isAdmin ? "Admin Portal" : "Sign In"}
        </h2>
        {isAdmin && <ShieldCheck className="w-5 h-5 text-accent" />}
      </div>

      <div className="flex-1 px-6 py-6 overflow-y-auto">
        {/* Role Toggle */}
        <div className="mb-6">
          <p className="text-xs text-muted-foreground font-semibold uppercase tracking-widest mb-2.5">
            Access type
          </p>
          <div className="flex bg-muted rounded-xl p-1 gap-1">
            <button
              type="button"
              onClick={() => setRole("user")}
              className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-lg text-sm font-semibold transition-all ${
                !isAdmin
                  ? "bg-white text-primary shadow-sm"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              <User className="w-4 h-4" />
              Player
            </button>
            <button
              type="button"
              onClick={() => setRole("admin")}
              className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-lg text-sm font-semibold transition-all ${
                isAdmin
                  ? "bg-secondary text-white shadow-sm"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              <ShieldCheck className="w-4 h-4" />
              Admin
            </button>
          </div>
          {isAdmin && (
            <p className="text-xs text-muted-foreground mt-2 text-center">
              Admin credentials required. Access is monitored.
            </p>
          )}
        </div>

        <form onSubmit={handleSubmit} className="space-y-5">
          {/* Email */}
          <div className="space-y-2">
            <label htmlFor="email" className="block text-sm font-medium text-foreground">
              {isAdmin ? "Admin Email" : "Email"}
            </label>
            <input
              id="email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder={isAdmin ? "admin@footballmaestro.com" : "your@email.com"}
              className={`w-full px-4 py-3 bg-input-background border rounded-xl focus:outline-none focus:ring-2 transition-all ${
                isAdmin
                  ? "border-secondary/40 focus:ring-secondary/40"
                  : "border-border focus:ring-primary/50"
              }`}
              required
            />
          </div>

          {/* Password */}
          <div className="space-y-2">
            <label htmlFor="password" className="block text-sm font-medium text-foreground">
              Password
            </label>
            <input
              id="password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              className={`w-full px-4 py-3 bg-input-background border rounded-xl focus:outline-none focus:ring-2 transition-all ${
                isAdmin
                  ? "border-secondary/40 focus:ring-secondary/40"
                  : "border-border focus:ring-primary/50"
              }`}
              required
            />
          </div>

          {/* Forgot password */}
          <div className="text-right">
            <button type="button" className="text-sm text-primary hover:text-secondary font-medium">
              Forgot password?
            </button>
          </div>

          {/* Sign In button */}
          <button
            type="submit"
            className={`w-full py-3.5 rounded-xl font-semibold text-base shadow-md transition-colors mt-2 ${
              isAdmin
                ? "bg-secondary text-white hover:bg-primary"
                : "bg-primary text-primary-foreground hover:bg-secondary"
            }`}
          >
            {isAdmin ? "Access Admin Panel" : "Sign In"}
          </button>

          {/* Divider — only for regular users */}
          {!isAdmin && (
            <>
              <div className="flex items-center gap-3 py-2">
                <div className="flex-1 h-px bg-border" />
                <span className="text-sm text-muted-foreground">or</span>
                <div className="flex-1 h-px bg-border" />
              </div>
              <button
                type="button"
                className="w-full bg-white text-foreground border border-border py-3.5 rounded-xl font-medium text-base shadow-sm hover:bg-muted transition-colors flex items-center justify-center gap-3"
              >
                <FcGoogle className="w-5 h-5" />
                Continue with Google
              </button>
            </>
          )}
        </form>

        {/* Register link — only for regular users */}
        {!isAdmin && (
          <div className="mt-8 text-center">
            <p className="text-sm text-muted-foreground">
              Don't have an account?{" "}
              <button onClick={onGoToRegister} className="text-primary hover:text-secondary font-semibold">
                Create one
              </button>
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
