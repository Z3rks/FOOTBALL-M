import { LayoutDashboard, Users, BarChart2, FileText } from "lucide-react";

interface AdminBottomNavProps {
  active: string;
  onNavigate: (screen: string) => void;
}

const navItems = [
  { id: "admin-dashboard", label: "Dashboard", icon: LayoutDashboard },
  { id: "admin-users", label: "Usuarios", icon: Users },
  { id: "admin-analytics", label: "Analytics", icon: BarChart2 },
  { id: "admin-reports", label: "Reportes", icon: FileText },
];

export default function AdminBottomNav({ active, onNavigate }: AdminBottomNavProps) {
  return (
    <div className="fixed bottom-0 left-1/2 -translate-x-1/2 w-full max-w-[375px] bg-secondary border-t border-white/10 shadow-lg">
      <div className="flex items-center justify-around py-2">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = active === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onNavigate(item.id)}
              className="flex flex-col items-center gap-1 py-1 px-3 min-w-[60px] transition-colors"
            >
              <Icon
                className={`w-5 h-5 transition-colors ${
                  isActive ? "text-accent" : "text-white/40"
                }`}
              />
              <span
                className={`text-[10px] font-semibold ${
                  isActive ? "text-accent" : "text-white/40"
                }`}
              >
                {item.label}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
}
