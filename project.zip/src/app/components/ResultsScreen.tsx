import { Trophy, Share2, RotateCcw, ArrowLeft, CheckCircle2, XCircle, Lightbulb } from "lucide-react";

interface ResultsScreenProps {
  onBack: () => void;
  onPlayAgain: () => void;
  onShare: () => void;
}

export default function ResultsScreen({ onBack, onPlayAgain, onShare }: ResultsScreenProps) {
  const score = 8;
  const total = 10;
  const accuracy = Math.round((score / total) * 100);

  const results = [
    { q: 1, correct: true },
    { q: 2, correct: true },
    { q: 3, correct: false },
    { q: 4, correct: true },
    { q: 5, correct: true },
    { q: 6, correct: true },
    { q: 7, correct: false },
    { q: 8, correct: true },
    { q: 9, correct: true },
    { q: 10, correct: true },
  ];

  return (
    <div className="h-screen w-full max-w-[375px] mx-auto bg-background flex flex-col">
      {/* Header */}
      <div className="px-4 py-4 flex items-center border-b border-border">
        <button onClick={onBack} className="p-2 -ml-2 hover:bg-muted rounded-lg transition-colors">
          <ArrowLeft className="w-5 h-5 text-foreground" />
        </button>
        <h2 className="flex-1 text-center text-xl font-semibold text-foreground -ml-9">Results</h2>
      </div>

      <div className="flex-1 overflow-y-auto px-4 py-6 space-y-6">
        {/* Score Display */}
        <div className="bg-gradient-to-br from-primary to-secondary rounded-2xl p-8 text-center shadow-lg">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-accent rounded-full mb-4">
            <Trophy className="w-10 h-10 text-primary" />
          </div>
          <h2 className="text-white text-5xl font-bold mb-2">
            {score}/{total}
          </h2>
          <p className="text-white/90 text-lg">Excellent work!</p>
          <div className="mt-4 inline-flex items-center gap-2 bg-white/10 px-4 py-2 rounded-full">
            <span className="text-accent font-bold text-lg">{accuracy}%</span>
            <span className="text-white/80 text-sm">Accuracy</span>
          </div>
        </div>

        {/* Summary */}
        <div className="bg-card border border-border rounded-xl p-4 shadow-sm">
          <div className="grid grid-cols-2 gap-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                <CheckCircle2 className="w-5 h-5 text-green-600" />
              </div>
              <div>
                <p className="text-2xl font-bold text-foreground">{score}</p>
                <p className="text-xs text-muted-foreground">Correct</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-red-100 rounded-lg flex items-center justify-center">
                <XCircle className="w-5 h-5 text-red-600" />
              </div>
              <div>
                <p className="text-2xl font-bold text-foreground">{total - score}</p>
                <p className="text-xs text-muted-foreground">Incorrect</p>
              </div>
            </div>
          </div>
        </div>

        {/* Wordle-style Result Grid */}
        <div className="bg-card border border-border rounded-xl p-4 shadow-sm">
          <h3 className="font-semibold text-sm text-foreground mb-3">Your Performance</h3>
          <div className="grid grid-cols-5 gap-2">
            {results.map((result, i) => (
              <div
                key={i}
                className={`aspect-square rounded-lg flex items-center justify-center font-bold text-xs ${
                  result.correct ? "bg-green-500 text-white" : "bg-red-500 text-white"
                }`}
              >
                {i + 1}
              </div>
            ))}
          </div>
        </div>

        {/* Fun Fact */}
        <div className="bg-accent/10 border border-accent/20 rounded-xl p-4">
          <div className="flex gap-3">
            <div className="flex-shrink-0">
              <div className="w-8 h-8 bg-accent rounded-lg flex items-center justify-center">
                <Lightbulb className="w-5 h-5 text-primary" />
              </div>
            </div>
            <div>
              <h4 className="font-semibold text-sm text-foreground mb-1">Did you know?</h4>
              <p className="text-sm text-muted-foreground">
                The fastest goal in World Cup history was scored just 11 seconds into a match by Hakan Şükür
                for Turkey against South Korea in 2002!
              </p>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="space-y-3 pb-4">
          <button
            onClick={onShare}
            className="w-full bg-primary text-primary-foreground py-3.5 rounded-xl font-semibold flex items-center justify-center gap-2 shadow-md hover:bg-secondary transition-colors"
          >
            <Share2 className="w-5 h-5" />
            Share Result
          </button>

          <button
            onClick={onPlayAgain}
            className="w-full bg-white text-primary border-2 border-primary py-3.5 rounded-xl font-semibold flex items-center justify-center gap-2 hover:bg-primary/5 transition-colors"
          >
            <RotateCcw className="w-5 h-5" />
            Play Again
          </button>

          <button
            onClick={onBack}
            className="w-full text-muted-foreground py-3 rounded-xl font-medium hover:bg-muted transition-colors"
          >
            Back to Mini-games
          </button>
        </div>
      </div>
    </div>
  );
}
