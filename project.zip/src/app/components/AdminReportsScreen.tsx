import { ShieldCheck, LogOut, Download, Trophy, TrendingUp, TrendingDown } from "lucide-react";
import AdminBottomNav from "./AdminBottomNav";

interface AdminReportsScreenProps {
  onNavigate: (screen: string) => void;
  onLogout: () => void;
}

const topPerformers = [
  { rank: 1, name: "MarcoBR", xp: 24810, badge: "🥇", color: "#F0B429", country: "🇧🇷", accuracy: 91 },
  { rank: 2, name: "CarlosR99", xp: 21340, badge: "🥈", color: "#9ca3af", country: "🇪🇸", accuracy: 87 },
  { rank: 3, name: "IvanKP", xp: 18920, badge: "🥉", color: "#b45309", country: "🇩🇪", accuracy: 84 },
  { rank: 4, name: "ElenaVP", xp: 16750, badge: "4", color: "#1A5276", country: "🇮🇹", accuracy: 82 },
  { rank: 5, name: "Pedro_V", xp: 15210, badge: "5", color: "#1A5276", country: "🇵🇹", accuracy: 79 },
];

const categoryReport = [
  { name: "Rules", games: "8.4k", acc: 83, trend: "up", color: "#F0B429" },
  { name: "Players", games: "14.8k", acc: 76, trend: "up", color: "#1A5276" },
  { name: "History", games: "9.9k", acc: 72, trend: "down", color: "#34d399" },
  { name: "Clubs", games: "11.3k", acc: 68, trend: "up", color: "#60a5fa" },
  { name: "Stadiums", games: "6.2k", acc: 61, trend: "down", color: "#a78bfa" },
  { name: "Transfers", games: "4.9k", acc: 54, trend: "down", color: "#fb7185" },
];

const weeklySnapshots = [
  { week: "Sem 33", users: 11240, games: 28400, xp: 2180000 },
  { week: "Sem 34", users: 11680, games: 31200, xp: 2340000 },
  { week: "Sem 35", users: 12100, games: 33800, xp: 2510000 },
  { week: "Sem 36", users: 12847, games: 33754, xp: 2640000 },
];

export default function AdminReportsScreen({ onNavigate, onLogout }: AdminReportsScreenProps) {
  return (
    <div className="h-screen w-full max-w-[375px] mx-auto bg-background flex flex-col">
      {/* Header */}
      <div className="bg-secondary px-4 pt-4 pb-3 shadow-lg">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-accent/20 flex items-center justify-center">
              <ShieldCheck className="w-5 h-5 text-accent" />
            </div>
            <div>
              <p className="text-white/50 text-[10px] font-bold uppercase tracking-widest leading-none">Admin Portal</p>
              <p className="text-white font-bold text-sm leading-tight">Reportes</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button className="flex items-center gap-1.5 bg-accent/20 px-3 py-1.5 rounded-full text-accent text-xs font-semibold hover:bg-accent/30 transition-colors">
              <Download className="w-3.5 h-3.5" />
              CSV
            </button>
            <button
              onClick={onLogout}
              className="flex items-center gap-1.5 bg-white/10 px-3 py-1.5 rounded-full text-white/80 text-xs font-semibold hover:bg-white/20 transition-colors"
            >
              <LogOut className="w-3.5 h-3.5" />
              Salir
            </button>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto pb-20">
        <div className="p-4 space-y-4">

          {/* Período */}
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-base font-bold text-foreground">Reportes Agosto 2026</h2>
              <p className="text-xs text-muted-foreground">Datos agregados de plataforma</p>
            </div>
            <button className="text-xs font-semibold text-primary border border-primary/30 px-3 py-1.5 rounded-full hover:bg-primary/5 transition-colors">
              Cambiar mes
            </button>
          </div>

          {/* Métricas clave */}
          <div className="grid grid-cols-2 gap-3">
            {[
              { label: "Total partidas", value: "384,210", sub: "De todos los tiempos", icon: "🎮" },
              { label: "Duración media", value: "8.4 min", sub: "Este mes", icon: "⏱️" },
              { label: "Preguntas resp.", value: "2.1M", sub: "De todos los tiempos", icon: "❓" },
              { label: "XP diario prom.", value: "187 XP", sub: "Por usuario activo", icon: "⚡" },
            ].map(({ label, value, sub, icon }) => (
              <div key={label} className="bg-card border border-border rounded-xl p-3.5 shadow-sm">
                <span className="text-xl">{icon}</span>
                <p className="text-xl font-bold text-foreground mt-1">{value}</p>
                <p className="text-xs font-semibold text-foreground">{label}</p>
                <p className="text-xs text-muted-foreground">{sub}</p>
              </div>
            ))}
          </div>

          {/* Snapshots semanales */}
          <div className="bg-card border border-border rounded-2xl p-4 shadow-sm">
            <h3 className="text-sm font-bold text-foreground mb-3">Resumen Semanal</h3>
            <div className="space-y-0">
              <div className="grid grid-cols-4 gap-1 pb-2 border-b border-border">
                {["Semana", "Usuarios", "Partidas", "XP total"].map((h) => (
                  <p key={h} className="text-[10px] font-bold text-muted-foreground uppercase tracking-wide">{h}</p>
                ))}
              </div>
              {weeklySnapshots.map(({ week, users, games, xp }, i) => (
                <div
                  key={week}
                  className={`grid grid-cols-4 gap-1 py-2.5 border-b border-border/50 last:border-0 ${
                    i === weeklySnapshots.length - 1 ? "bg-primary/5 -mx-4 px-4 rounded-b-2xl" : ""
                  }`}
                >
                  <p className="text-xs font-semibold text-foreground">{week}</p>
                  <p className="text-xs text-muted-foreground">{(users / 1000).toFixed(1)}k</p>
                  <p className="text-xs text-muted-foreground">{(games / 1000).toFixed(1)}k</p>
                  <p className="text-xs font-semibold text-primary">{(xp / 1000000).toFixed(1)}M</p>
                </div>
              ))}
            </div>
          </div>

          {/* Top performers */}
          <div className="bg-card border border-border rounded-2xl p-4 shadow-sm">
            <div className="flex items-center gap-2 mb-3">
              <Trophy className="w-4 h-4 text-accent" />
              <h3 className="text-sm font-bold text-foreground">Top Jugadores</h3>
            </div>
            <div className="space-y-3">
              {topPerformers.map(({ rank, name, xp, badge, color, country, accuracy }) => (
                <div key={`rpt-perf-${rank}`} className="flex items-center gap-3">
                  <div
                    className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                      rank <= 3 ? "bg-accent/10 text-lg" : "bg-muted text-xs font-bold text-muted-foreground"
                    }`}
                  >
                    {badge}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between mb-1">
                      <div className="flex items-center gap-1.5">
                        <p className="text-sm font-semibold text-foreground">{name}</p>
                        <span className="text-sm">{country}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs text-muted-foreground">{accuracy}%</span>
                        <p className="text-xs font-bold text-primary">{xp.toLocaleString()} XP</p>
                      </div>
                    </div>
                    <div className="w-full h-1.5 bg-muted rounded-full overflow-hidden">
                      <div
                        className="h-full rounded-full transition-all"
                        style={{ width: `${(xp / 24810) * 100}%`, background: color }}
                      />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Rendimiento por categoría */}
          <div className="bg-card border border-border rounded-2xl p-4 shadow-sm">
            <h3 className="text-sm font-bold text-foreground mb-3">Rendimiento por Categoría</h3>
            <div>
              <div className="grid grid-cols-4 gap-1 pb-2 border-b border-border">
                {["Categoría", "Partidas", "Prec.", ""].map((h) => (
                  <p key={h} className="text-[10px] font-bold text-muted-foreground uppercase tracking-wide">{h}</p>
                ))}
              </div>
              {categoryReport.map(({ name, games, acc, trend, color }) => (
                <div key={`rpt-cat-${name}`} className="grid grid-cols-4 gap-1 items-center py-2.5 border-b border-border/50 last:border-0">
                  <div className="flex items-center gap-1.5 col-span-1">
                    <div className="w-2 h-2 rounded-full flex-shrink-0" style={{ background: color }} />
                    <p className="text-xs font-medium text-foreground truncate">{name}</p>
                  </div>
                  <p className="text-xs text-muted-foreground">{games}</p>
                  <p className="text-xs font-bold" style={{ color }}>{acc}%</p>
                  <div className="flex justify-end">
                    {trend === "up"
                      ? <TrendingUp className="w-3.5 h-3.5 text-emerald-500" />
                      : <TrendingDown className="w-3.5 h-3.5 text-red-400" />
                    }
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Actividad por hora del día */}
          <div className="bg-card border border-border rounded-2xl p-4 shadow-sm">
            <h3 className="text-sm font-bold text-foreground mb-1">Pico de Actividad</h3>
            <p className="text-xs text-muted-foreground mb-3">Sesiones por hora del día (promedio)</p>
            <div className="flex items-end gap-0.5 h-14">
              {[12, 18, 25, 40, 55, 70, 82, 95, 88, 74, 60, 45, 38, 30, 22, 18, 15, 20, 35, 58, 72, 68, 50, 30].map(
                (h, i) => (
                  <div
                    key={`rpt-hour-${i}`}
                    className="flex-1 rounded-t-sm transition-all"
                    style={{
                      height: `${h}%`,
                      background: i >= 18 && i <= 22 ? "#F0B429" : "rgba(26,82,118,0.3)",
                    }}
                    title={`${i}:00h`}
                  />
                )
              )}
            </div>
            <div className="flex justify-between mt-1.5">
              <span className="text-xs text-muted-foreground">00:00</span>
              <span className="text-xs text-accent font-semibold">🔥 Pico: 20–22h</span>
              <span className="text-xs text-muted-foreground">23:00</span>
            </div>
          </div>

          {/* Botón exportar */}
          <button className="w-full border-2 border-dashed border-border rounded-xl py-4 text-sm font-semibold text-muted-foreground hover:border-primary hover:text-primary transition-colors flex items-center justify-center gap-2">
            <Download className="w-4 h-4" />
            Exportar Reporte Completo (CSV)
          </button>
        </div>
      </div>

      <AdminBottomNav active="admin-reports" onNavigate={onNavigate} />
    </div>
  );
}
