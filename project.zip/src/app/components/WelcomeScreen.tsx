import { Trophy } from "lucide-react";
import { FcGoogle } from "react-icons/fc";

interface WelcomeScreenProps {
  onSignIn: () => void;
  onCreateAccount: () => void;
}

export default function WelcomeScreen({ onSignIn, onCreateAccount }: WelcomeScreenProps) {
  return (
    <div className="h-screen w-full max-w-[375px] mx-auto bg-background flex flex-col relative overflow-hidden">
      {/* Subtle football field pattern */}
      <div className="absolute inset-0 opacity-[0.03]">
        <div className="absolute inset-0" style={{
          backgroundImage: `
            repeating-linear-gradient(0deg, transparent, transparent 50px, #1A5276 50px, #1A5276 51px),
            repeating-linear-gradient(90deg, transparent, transparent 50px, #1A5276 50px, #1A5276 51px)
          `,
        }} />
      </div>

      <div className="relative z-10 flex-1 flex flex-col items-center justify-center px-6">
        {/* Logo */}
        <div className="bg-primary rounded-full p-6 mb-6 shadow-lg">
          <Trophy className="w-16 h-16 text-accent" />
        </div>

        <h1 className="text-3xl font-bold text-primary mb-2 text-center">Football Maestro</h1>
        <p className="text-lg text-muted-foreground mb-12 text-center">Become a Football Maestro</p>

        {/* Buttons */}
        <div className="w-full space-y-3">
          <button
            onClick={onSignIn}
            className="w-full bg-primary text-primary-foreground py-3.5 rounded-xl font-semibold text-lg shadow-md hover:bg-secondary transition-colors"
          >
            Sign In
          </button>

          <button
            onClick={onCreateAccount}
            className="w-full bg-white text-primary border-2 border-primary py-3.5 rounded-xl font-semibold text-lg hover:bg-primary/5 transition-colors"
          >
            Create Account
          </button>

          {/* Divider */}
          <div className="flex items-center gap-3 py-2">
            <div className="flex-1 h-px bg-border" />
            <span className="text-sm text-muted-foreground">or</span>
            <div className="flex-1 h-px bg-border" />
          </div>

          <button className="w-full bg-white text-foreground border border-border py-3.5 rounded-xl font-medium text-base shadow-sm hover:bg-muted transition-colors flex items-center justify-center gap-3">
            <FcGoogle className="w-5 h-5" />
            Continue with Google
          </button>
        </div>
      </div>

      {/* Footer */}
      <div className="relative z-10 pb-8 text-center text-sm text-muted-foreground">
        <p>Learn football through fun challenges</p>
      </div>
    </div>
  );
}
