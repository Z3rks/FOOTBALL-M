import { Clock, ExternalLink } from "lucide-react";
import BottomNav from "./BottomNav";

interface NewsScreenProps {
  onNavigate: (screen: string) => void;
}

const newsCategories = ["All", "Transfers", "Champions League", "World Cup", "Premier League"];

const newsArticles = [
  {
    id: 1,
    title: "Real Madrid wins Champions League final in dramatic fashion",
    description: "Los Blancos secure their 15th European Cup with a last-minute winner",
    source: "ESPN",
    timeAgo: "2h ago",
    category: "Champions League",
    image: "https://images.unsplash.com/photo-1579952363873-27f3bade9f55?w=400&h=200&fit=crop",
  },
  {
    id: 2,
    title: "Record transfer: Mbappé completes move to Real Madrid",
    description: "French superstar signs five-year deal in blockbuster transfer",
    source: "Sky Sports",
    timeAgo: "5h ago",
    category: "Transfers",
    image: "https://images.unsplash.com/photo-1522778119026-d647f0596c20?w=400&h=200&fit=crop",
  },
  {
    id: 3,
    title: "Manchester City maintains perfect start to the season",
    description: "Haaland scores hat-trick as City demolish rivals 5-0",
    source: "BBC Sport",
    timeAgo: "8h ago",
    category: "Premier League",
    image: "https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=400&h=200&fit=crop",
  },
  {
    id: 4,
    title: "World Cup 2026: Venues announced for North American tournament",
    description: "FIFA reveals the stadiums that will host the expanded 48-team competition",
    source: "Goal",
    timeAgo: "12h ago",
    category: "World Cup",
    image: "https://images.unsplash.com/photo-1431324155629-1a6deb1dec8d?w=400&h=200&fit=crop",
  },
  {
    id: 5,
    title: "Liverpool signs promising young midfielder from Bundesliga",
    description: "Reds secure signature of German talent in £45m deal",
    source: "The Athletic",
    timeAgo: "1d ago",
    category: "Transfers",
    image: "https://images.unsplash.com/photo-1574629810360-7efbbe195018?w=400&h=200&fit=crop",
  },
  {
    id: 6,
    title: "Barcelona's youngsters shine in Champions League victory",
    description: "La Masia graduates lead Barça to impressive 3-1 away win",
    source: "Marca",
    timeAgo: "1d ago",
    category: "Champions League",
    image: "https://images.unsplash.com/photo-1560272564-c83b66b1ad12?w=400&h=200&fit=crop",
  },
];

export default function NewsScreen({ onNavigate }: NewsScreenProps) {
  return (
    <div className="h-screen w-full max-w-[375px] mx-auto bg-background flex flex-col">
      {/* Header */}
      <div className="bg-primary px-4 py-4 shadow-md">
        <h1 className="text-white text-2xl font-bold">Football News</h1>
        <p className="text-white/80 text-sm mt-1">Stay updated with the latest</p>
      </div>

      {/* Category Tabs */}
      <div className="px-4 py-3 bg-white border-b border-border overflow-x-auto">
        <div className="flex gap-2">
          {newsCategories.map((category, index) => (
            <button
              key={category}
              className={`px-4 py-2 rounded-full text-sm font-semibold whitespace-nowrap transition-colors ${
                index === 0
                  ? "bg-primary text-white"
                  : "bg-muted text-muted-foreground hover:bg-primary/10"
              }`}
            >
              {category}
            </button>
          ))}
        </div>
      </div>

      {/* News Feed */}
      <div className="flex-1 overflow-y-auto pb-20 px-4 py-4 space-y-4">
        {newsArticles.map((article) => (
          <div
            key={article.id}
            className="bg-card border border-border rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-shadow cursor-pointer"
          >
            <img src={article.image} alt={article.title} className="w-full h-40 object-cover" />
            <div className="p-4">
              <div className="flex items-center gap-2 mb-2">
                <span className="text-xs font-semibold text-primary bg-primary/10 px-2 py-1 rounded">
                  {article.category}
                </span>
                <div className="flex items-center gap-1 text-muted-foreground">
                  <Clock className="w-3 h-3" />
                  <span className="text-xs">{article.timeAgo}</span>
                </div>
              </div>
              <h3 className="font-bold text-base text-foreground mb-2 line-clamp-2">{article.title}</h3>
              <p className="text-sm text-muted-foreground mb-3 line-clamp-2">{article.description}</p>
              <div className="flex items-center justify-between">
                <span className="text-xs font-medium text-muted-foreground">{article.source}</span>
                <button className="text-primary hover:text-secondary transition-colors">
                  <ExternalLink className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Bottom Navigation */}
      <BottomNav active="news" onNavigate={onNavigate} />
    </div>
  );
}
