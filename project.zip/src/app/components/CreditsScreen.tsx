import { Coins, Trophy, Share2, Flame, Gift, User, Crown, Palette, MapPin } from "lucide-react";
import BottomNav from "./BottomNav";

interface CreditsScreenProps {
  onNavigate: (screen: string) => void;
}

const storeItems = [
  {
    id: 1,
    name: "Golden Ball Avatar",
    type: "Avatar",
    cost: 500,
    icon: "⚽",
    color: "bg-yellow-100",
  },
  {
    id: 2,
    name: "Champions Badge Frame",
    type: "Badge Frame",
    cost: 750,
    icon: "🏆",
    color: "bg-blue-100",
  },
  {
    id: 3,
    name: "Fire Ball Icon",
    type: "Ball Icon",
    cost: 300,
    icon: "🔥",
    color: "bg-red-100",
  },
  {
    id: 4,
    name: "Camp Nou Background",
    type: "Stadium",
    cost: 1000,
    icon: "🏟️",
    color: "bg-green-100",
  },
  {
    id: 5,
    name: "Royal Crown Avatar",
    type: "Avatar",
    cost: 600,
    icon: "👑",
    color: "bg-purple-100",
  },
  {
    id: 6,
    name: "Rainbow Badge Frame",
    type: "Badge Frame",
    cost: 800,
    icon: "🌈",
    color: "bg-pink-100",
  },
];

const earnMethods = [
  { method: "Complete Daily Challenge", credits: 50, icon: Trophy },
  { method: "Maintain 7-day streak", credits: 100, icon: Flame },
  { method: "Share your results", credits: 25, icon: Share2 },
  { method: "Refer a friend", credits: 200, icon: Gift },
];

export default function CreditsScreen({ onNavigate }: CreditsScreenProps) {
  const userCredits = 1250;

  return (
    <div className="h-screen w-full max-w-[375px] mx-auto bg-background flex flex-col">
      {/* Header */}
      <div className="bg-primary px-4 py-4 shadow-md">
        <h1 className="text-white text-2xl font-bold">Credits Store</h1>
        <p className="text-white/80 text-sm mt-1">Customize your profile</p>
      </div>

      {/* Credits Balance */}
      <div className="px-4 py-4 bg-gradient-to-br from-accent/20 to-accent/5 border-b border-border">
        <div className="flex items-center justify-center gap-3">
          <div className="w-12 h-12 bg-accent rounded-full flex items-center justify-center">
            <Coins className="w-7 h-7 text-primary" />
          </div>
          <div>
            <p className="text-sm text-muted-foreground">Your Balance</p>
            <p className="text-3xl font-bold text-foreground">{userCredits.toLocaleString()}</p>
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto pb-20">
        {/* How to Earn */}
        <div className="px-4 py-4 bg-white border-b border-border">
          <h3 className="text-lg font-bold text-foreground mb-3">How to Earn Credits</h3>
          <div className="space-y-2">
            {earnMethods.map((method, index) => {
              const Icon = method.icon;
              return (
                <div key={index} className="flex items-center gap-3 p-3 bg-muted/50 rounded-lg">
                  <div className="w-8 h-8 bg-primary/10 rounded-lg flex items-center justify-center">
                    <Icon className="w-5 h-5 text-primary" />
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-medium text-foreground">{method.method}</p>
                  </div>
                  <div className="flex items-center gap-1 text-accent font-bold">
                    <Coins className="w-4 h-4" />
                    <span className="text-sm">+{method.credits}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Store Items */}
        <div className="px-4 py-4">
          <h3 className="text-lg font-bold text-foreground mb-3">Store Items</h3>
          <div className="grid grid-cols-2 gap-3">
            {storeItems.map((item) => {
              const canAfford = userCredits >= item.cost;
              return (
                <div
                  key={item.id}
                  className={`bg-card border rounded-xl p-4 shadow-sm transition-all ${
                    canAfford
                      ? "border-border hover:shadow-md cursor-pointer"
                      : "border-border opacity-60"
                  }`}
                >
                  <div className={`${item.color} w-16 h-16 rounded-xl flex items-center justify-center text-3xl mb-3 mx-auto`}>
                    {item.icon}
                  </div>
                  <h4 className="font-semibold text-sm text-foreground mb-1 text-center line-clamp-2 min-h-[40px]">
                    {item.name}
                  </h4>
                  <p className="text-xs text-muted-foreground text-center mb-3">{item.type}</p>
                  <div className="flex items-center justify-center gap-1.5">
                    <Coins className="w-4 h-4 text-accent" />
                    <span className="font-bold text-foreground">{item.cost}</span>
                  </div>
                  <button
                    disabled={!canAfford}
                    className={`w-full mt-3 py-2 rounded-lg font-semibold text-sm transition-colors ${
                      canAfford
                        ? "bg-primary text-white hover:bg-secondary"
                        : "bg-muted text-muted-foreground cursor-not-allowed"
                    }`}
                  >
                    {canAfford ? "Purchase" : "Not Enough"}
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Bottom Navigation */}
      <BottomNav active="credits" onNavigate={onNavigate} />
    </div>
  );
}
