import { Brain, Star, Clock, Users, Trophy, Calendar, DollarSign, Target, Zap, Shield } from "lucide-react";
import BottomNav from "./BottomNav";

interface MinigamesScreenProps {
  onNavigate: (screen: string) => void;
  onPlayGame: () => void;
}

const miniGames = [
  {
    id: 1,
    name: "Who is it?",
    description: "Guess the player with progressive clues",
    category: "Players",
    difficulty: "Easy",
    icon: "🤔",
    color: "bg-blue-500",
  },
  {
    id: 2,
    name: "Silhouette",
    description: "Recognize the player by their shadow",
    category: "Players",
    difficulty: "Medium",
    icon: "👤",
    color: "bg-purple-500",
  },
  {
    id: 3,
    name: "Guess the Badge",
    description: "Identify the club from pixelated crest",
    category: "Clubs",
    difficulty: "Hard",
    icon: "🛡️",
    color: "bg-red-500",
  },
  {
    id: 4,
    name: "Guess the Stadium",
    description: "Name the stadium from a blurred photo",
    category: "Stadiums",
    difficulty: "Medium",
    icon: "🏟️",
    color: "bg-green-500",
  },
  {
    id: 5,
    name: "Connections",
    description: "Group players by something in common",
    category: "Logic",
    difficulty: "Hard",
    icon: "🔗",
    color: "bg-indigo-500",
  },
  {
    id: 6,
    name: "Timeline",
    description: "Order historical events chronologically",
    category: "History",
    difficulty: "Medium",
    icon: "📅",
    color: "bg-orange-500",
  },
  {
    id: 7,
    name: "The Transfer",
    description: "Which club did this player go to next?",
    category: "Transfers",
    difficulty: "Hard",
    icon: "🔄",
    color: "bg-pink-500",
  },
  {
    id: 8,
    name: "How much was he worth?",
    description: "Guess the transfer value",
    category: "Transfers",
    difficulty: "Hard",
    icon: "💰",
    color: "bg-yellow-500",
  },
  {
    id: 9,
    name: "Dream Team",
    description: "Complete the historical lineup",
    category: "Teams",
    difficulty: "Expert",
    icon: "⭐",
    color: "bg-cyan-500",
  },
  {
    id: 10,
    name: "Goal or No Goal?",
    description: "Was the play valid or offside?",
    category: "Rules",
    difficulty: "Medium",
    icon: "⚖️",
    color: "bg-teal-500",
  },
];

const difficultyColors = {
  Easy: "text-green-600 bg-green-50 border-green-200",
  Medium: "text-orange-600 bg-orange-50 border-orange-200",
  Hard: "text-red-600 bg-red-50 border-red-200",
  Expert: "text-purple-600 bg-purple-50 border-purple-200",
};

export default function MinigamesScreen({ onNavigate, onPlayGame }: MinigamesScreenProps) {
  return (
    <div className="h-screen w-full max-w-[375px] mx-auto bg-background flex flex-col">
      {/* Header */}
      <div className="bg-primary px-4 py-4 shadow-md">
        <h1 className="text-white text-2xl font-bold">Mini-games</h1>
        <p className="text-white/80 text-sm mt-1">Test your football knowledge</p>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto pb-20 px-4 py-4">
        <div className="grid grid-cols-2 gap-3">
          {miniGames.map((game) => (
            <div
              key={game.id}
              onClick={onPlayGame}
              className="bg-card border border-border rounded-xl p-4 shadow-sm hover:shadow-md transition-all cursor-pointer active:scale-95"
            >
              <div className="text-4xl mb-3">{game.icon}</div>
              <h3 className="font-bold text-sm text-foreground mb-1 line-clamp-2 min-h-[40px]">{game.name}</h3>
              <p className="text-xs text-muted-foreground mb-3 line-clamp-2 min-h-[32px]">{game.description}</p>
              <div className="space-y-2">
                <div className="flex items-center gap-1.5">
                  <Star className="w-3.5 h-3.5 text-muted-foreground" />
                  <span className="text-xs text-muted-foreground">{game.category}</span>
                </div>
                <div className={`text-xs font-semibold px-2 py-1 rounded-md border inline-block ${
                  difficultyColors[game.difficulty as keyof typeof difficultyColors]
                }`}>
                  {game.difficulty}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Bottom Navigation */}
      <BottomNav active="minigames" onNavigate={onNavigate} />
    </div>
  );
}
